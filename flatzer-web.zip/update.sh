#!/usr/bin/env bash
# Update dari GitHub: sudo ./update.sh
set -euo pipefail
cd "$(dirname "$0")"
git pull --ff-only
npm install --no-audit --no-fund
npm run build
chown -R flatzer:flatzer . 2>/dev/null || true
systemctl restart flatzer
echo "Flatzer diperbarui."
