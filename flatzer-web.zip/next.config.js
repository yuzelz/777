module.exports = { experimental: { instrumentationHook: true, serverComponentsExternalPackages: ['better-sqlite3', 'grammy', 'qrcode'] } };
