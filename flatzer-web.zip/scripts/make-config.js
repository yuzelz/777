// Membuat config.json dari argumen (dipanggil install.sh). Bukan env, dan tidak ikut GitHub.
import fs from 'fs';
const [base, admin, bot, bih, slug, pk, wh, tsk, tss, markup] = process.argv.slice(2);
const cfg = { base_domain: base, admin_tg_id: +admin, bot_token: bot, bihost_api_key: bih, pakasir_slug: slug, pakasir_api_key: pk, pakasir_webhook_secret: wh, turnstile_site_key: tsk, turnstile_secret: tss, markup_percent: +markup || 20 };
fs.writeFileSync('config.json', JSON.stringify(cfg, null, 2) + '\n', { mode: 0o600 });
console.log('config.json dibuat');
