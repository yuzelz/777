// Menjalankan bot Telegram (login + notifikasi) dan job terjadwal di dalam proses website.
export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs' || globalThis.__flatzerStarted) return;
  globalThis.__flatzerStarted = true;
  const { startBot } = await import('./src/server/bot.js');
  const { startJobs } = await import('./src/server/jobs.js');
  startBot(); startJobs();
}
