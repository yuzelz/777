# Flatzer — website, open API, bot login & notifikasi
Next.js + SQLite (satu database bersama), satu proses. Login hanya lewat Telegram, pembayaran QRIS lewat Pakasir v2, VPS lewat API BIHost. Konfigurasi di `config.json` (dibuat installer, **tidak ikut GitHub**), bukan env.

## Pasang di VPS (setelah di-clone dari GitHub)
```
git clone <repo-kamu> flatzer && cd flatzer
sudo ./install.sh
```
Installer menanyakan: domain utama, ID Telegram admin (default 5979067091), token bot, API key BIHost, data Pakasir, Turnstile, markup, dan token Cloudflare Tunnel. Lalu ia membuat `config.json`, build, service systemd `flatzer`, dan memasang `cloudflared`.

Di Cloudflare Zero Trust, arahkan semua hostname ke `HTTP localhost:3000`:
`flatzer.my.id`, `www.flatzer.my.id`, `dash.flatzer.my.id`, `api.flatzer.my.id`, `docs.flatzer.my.id`.
Catatan: pakai `api.` bukan `www.api.` — sertifikat gratis Cloudflare hanya mencakup satu level subdomain (aplikasi tetap mengenali `www.api.` jika kamu punya sertifikatnya).

| Host | Isi |
|---|---|
| `flatzer.my.id`, `www.` | landing, syarat |
| `dash.` | login Telegram (+Turnstile), dashboard, `/admin` |
| `api.` | REST API `https://api.<domain>/v1/...` (120 req/menit) |
| `docs.` | dokumentasi API |

Setelan eksternal: Pakasir webhook `https://api.<domain>/v1/webhook/pakasir` dengan header `X-Secret` sama seperti `pakasir_webhook_secret`; Turnstile hostname `<domain>`.

Update: `sudo ./update.sh` (git pull, build, restart). Log: `journalctl -u flatzer -f`.

## Admin
Login di `dash.<domain>` dengan akun Telegram yang ID-nya = `admin_tg_id`, lalu buka `/admin`: statistik, markup, diskon nyata, domain, pengguna (ubah saldo), VPS, order.

## Migrasi domain
1. Tambahkan hostname domain baru di Cloudflare Tunnel (lima hostname di atas).
2. `/admin` → Domain → simpan domain baru. Aplikasi tidak menyimpan domain di kode: semua routing berdasarkan host request, jadi domain baru langsung jalan. Pengguna perlu login ulang sekali (cookie per domain).
3. Perbarui Pakasir webhook dan Turnstile hostname ke domain baru (ditampilkan di panel admin).

## Backup dan migrasi server
Backup otomatis tiap hari: salinan SQLite dikirim ke Telegram admin. Di server baru: pasang seperti biasa, simpan file backup sebagai `data/restore.db`, lalu start. Saat start file itu menggantikan database (lalu diganti nama `restore.db.done`). Semua akun, saldo, VPS, dan order ikut pindah.

## Open API
Kunci ada di dashboard (tab API). Header `Authorization: Bearer fz_...`. Endpoint: `GET /me`, `POST /me {rotate}`, `GET /catalog`, `POST /pay`, `GET /orders/{id}`, `GET|POST /vps`. Detail dan contoh di `docs.<domain>`.

## Catatan
- Bot hanya untuk login dan notifikasi, berjalan di dalam proses website (long polling).
- QRIS minimal Rp 500 (aturan Pakasir). Biaya admin ditanggung pelanggan dan ditampilkan sebelum bayar.
- Pembayaran dikonfirmasi dua jalur: webhook dan cek status berkala dari browser (Pakasir v2 membatasi 1x per 4 detik).
- Password root pada order QRIS disimpan sementara di tabel order sampai VPS ter-deploy, lalu dikosongkan.
- `config.json` dan `data/` berisi rahasia: jangan di-commit (sudah di `.gitignore`).
