import { cfg } from './config.js';
import { getSetting } from './settings.js';
// Domain utama dapat diganti dari panel admin (migrasi domain), tanpa ubah kode atau restart.
export const configuredBase = () => getSetting('base_domain') || cfg.base_domain || 'localhost';
export const dashUrl = () => `https://dash.${configuredBase()}`;
