import fs from 'fs';
import { db } from './db.js';
import { cfg } from './config.js';
import { bih } from './bihost.js';
import { price } from './pricing.js';
import { notify } from './notify.js';
import { extend, charge } from './orders.js';
import { bot, InputFile } from './bot.js';
import { getSetting, setSetting } from './settings.js';

// Tiap jam: auto-renew, pengingat 3 & 1 hari, hapus VPS expired.
export async function sweep() {
  for (const v of db.prepare('SELECT * FROM vps').all()) {
    const left = v.expires_at - Date.now(), h = JSON.parse(v.data).hostname, warned = JSON.parse(v.warned);
    if (v.auto && left > 0 && left < 864e5 && charge(v.user_id, price(v.plan))) { extend(v.id); notify(v.user_id, { id: `VPS ${h} diperpanjang otomatis dari saldo.`, en: `VPS ${h} was renewed automatically from your balance.` }); continue; }
    if (left <= 0) {
      try { await bih('DELETE', `/vps/${v.id}`); } catch (e) { if (e.message !== 'VPS_NOT_FOUND') continue; }
      db.prepare('DELETE FROM vps WHERE id=?').run(v.id);
      notify(v.user_id, { id: `VPS ${h} kedaluwarsa dan sudah dihapus.`, en: `VPS ${h} expired and was deleted.` });
    } else {
      const d = left < 864e5 ? 1 : left < 3 * 864e5 ? 3 : 0;
      if (d && !warned.includes(d)) { warned.push(d); db.prepare('UPDATE vps SET warned=? WHERE id=?').run(JSON.stringify(warned), v.id); notify(v.user_id, { id: `VPS ${h} kedaluwarsa dalam ${d} hari. Perpanjang agar tidak dihapus.`, en: `VPS ${h} expires in ${d} day(s). Renew to keep it.` }); }
    }
  }
}
// Backup harian: salinan SQLite dikirim ke Telegram admin. Migrasi: taruh file itu di data/restore.db.
async function backup() {
  if (!bot || !cfg.admin_tg_id || Date.now() - +(getSetting('last_backup') || 0) < 864e5) return;
  const f = `data/backup-${Date.now()}.db`;
  await db.backup(f);
  await bot.api.sendDocument(cfg.admin_tg_id, new InputFile(f, `flatzer-${new Date().toISOString().slice(0, 10)}.db`), { caption: 'Backup harian Flatzer. Migrasi: simpan sebagai data/restore.db di server baru lalu start.' });
  fs.unlinkSync(f); setSetting('last_backup', Date.now());
}
export function startJobs() {
  const run = () => { sweep().catch(console.error); backup().catch(e => console.error('[backup]', e.message)); };
  setInterval(run, 36e5); setTimeout(run, 15000);
}
