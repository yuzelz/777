import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { cookies } from 'next/headers';
import { cfg } from './config.js';
import { db } from './db.js';
import { getSetting } from './settings.js';
export const newApiKey = () => 'fz_' + crypto.randomBytes(20).toString('hex');
export const signSession = uid => jwt.sign({ uid }, getSetting('jwt_secret'), { expiresIn: '30d' });
// Cookie dibagi ke semua subdomain (domain induk) agar login di dash. juga berlaku di api./docs.
export const cookieOpts = host => {
  const h = (host || '').split(':')[0].toLowerCase().replace(/^((www|dash|api|docs)\.)+/, ''), local = /^(localhost|\d+\.\d+\.\d+\.\d+)$/.test(h) || !h.includes('.');
  return { httpOnly: true, secure: !local, sameSite: 'lax', path: '/', maxAge: 2592000, ...(local ? {} : { domain: '.' + h }) };
};
// Cookie sesi (website) atau "Authorization: Bearer fz_..." (open API).
export function getUser(req) {
  const a = req?.headers.get('authorization') || '';
  if (a.startsWith('Bearer fz_')) return db.prepare('SELECT * FROM users WHERE api_key=?').get(a.slice(7));
  try { return db.prepare('SELECT * FROM users WHERE id=?').get(jwt.verify(cookies().get('fz')?.value, getSetting('jwt_secret')).uid); } catch { return null; }
}
export const isAdmin = u => !!u && u.tg_id === cfg.admin_tg_id;
