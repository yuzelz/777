import QRCode from 'qrcode';
import { db } from './db.js';
import { bih } from './bihost.js';
import { createTxn, txnStatus } from './pakasir.js';
import { notify } from './notify.js';
import { delSetting } from './settings.js';

export const charge = (uid, a) => db.prepare('UPDATE users SET balance=balance-? WHERE id=? AND balance>=?').run(a, uid, a).changes > 0;
export const refund = (uid, a) => db.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(a, uid);
export function extend(id) {
  db.prepare('UPDATE vps SET expires_at=max(expires_at,?)+?,warned=? WHERE id=?').run(Date.now(), 30 * 864e5, '[]', id);
}
export async function deploy(uid, p) {
  const d = (await bih('POST', '/vps', { plan: p.plan, image_vmid: +p.img, hostname: p.host, root_password: p.pw })).data;
  db.prepare('INSERT INTO vps(id,user_id,plan,data,expires_at) VALUES(?,?,?,?,?)').run(d.id, uid, p.plan, JSON.stringify(d), Date.now() + 30 * 864e5);
  notify(uid, { id: `VPS ${d.hostname} sudah aktif.`, en: `VPS ${d.hostname} is now active.` }, [['SSH', `ssh root@${d.access.ipv4} -p ${d.access.ssh_port}`]]);
  return d;
}
// Buat transaksi QRIS Pakasir v2 + simpan order. Mengembalikan data untuk ditampilkan (QR sebagai data URL).
export async function qrisOrder(uid, kind, amount, payload) {
  const id = `FZ${Date.now()}${uid}`, t = await createTxn(id, amount);
  db.prepare('INSERT INTO orders(id,user_id,kind,amount,txn_id,payload) VALUES(?,?,?,?,?,?)').run(id, uid, kind, amount, t.txn_id, JSON.stringify(payload));
  return { order_id: id, amount, fee: t.fee, total_payment: t.total_payment, expired_at: t.expired_at, qr: await QRCode.toDataURL(t.qr_string, { margin: 1, width: 320 }) };
}
export async function markPaid(id) {
  if (!db.prepare("UPDATE orders SET status='paid' WHERE id=? AND status='pending'").run(id).changes) return;
  const o = db.prepare('SELECT * FROM orders WHERE id=?').get(id), p = JSON.parse(o.payload || '{}');
  if (o.kind === 'topup') { refund(o.user_id, o.amount); notify(o.user_id, { id: `Saldo bertambah Rp ${o.amount.toLocaleString('id-ID')}.`, en: `Balance increased by Rp ${o.amount.toLocaleString('id-ID')}.` }); }
  else if (o.kind === 'renew') {
    if (db.prepare('SELECT 1 FROM vps WHERE id=?').get(p.id)) { extend(p.id); delSetting('warn:' + p.id); notify(o.user_id, { id: 'Masa aktif VPS diperpanjang 30 hari.', en: 'VPS validity extended by 30 days.' }); } else refund(o.user_id, o.amount);
  } else {
    try { await deploy(o.user_id, p); }
    catch { refund(o.user_id, o.amount); notify(o.user_id, { id: 'VPS gagal dibuat. Pembayaran dikembalikan ke saldo.', en: 'VPS creation failed. Payment was refunded to your balance.' }); }
    db.prepare("UPDATE orders SET payload='{}' WHERE id=?").run(id);
  }
}
// Cek status ke Pakasir (maks tiap 5 detik per order) lalu proses jika sudah dibayar.
export async function syncOrder(o) {
  if (o.status !== 'pending' || Date.now() - o.checked < 5000) return o.status;
  db.prepare('UPDATE orders SET checked=? WHERE id=?').run(Date.now(), o.id);
  const s = await txnStatus(o.txn_id);
  if (s.status === 'completed' && s.order_id === o.id && s.amount === o.amount) { await markPaid(o.id); return 'paid'; }
  if (s.status === 'canceled') { db.prepare("UPDATE orders SET status='canceled' WHERE id=?").run(o.id); return 'canceled'; }
  return 'pending';
}
