import { cfg } from './config.js';
import { getSetting } from './settings.js';
// Cek kesehatan layanan, di-cache 60 detik.
export async function getStatus() {
  const c = globalThis.__fzStatus;
  if (c && Date.now() - c.at < 60000) return c.v;
  const ping = async (u, h) => { try { const r = await fetch(u, { headers: h, signal: AbortSignal.timeout(4000), cache: 'no-store' }); return r.status < 500; } catch { return false; } };
  const [api, pay] = await Promise.all([ping('https://api.bihost.id/v1/plans', { Authorization: `Bearer ${cfg.bihost_api_key}` }), ping('https://pakasir.com/')]);
  const v = { site: true, api, pay, bot: !!getSetting('bot_username') };
  globalThis.__fzStatus = { at: Date.now(), v };
  return v;
}
