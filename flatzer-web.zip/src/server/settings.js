import crypto from 'crypto';
import { db } from './db.js';
export const getSetting = k => {
  const r = db.prepare('SELECT v FROM settings WHERE k=?').get(k);
  if (r) return r.v;
  if (k === 'jwt_secret') { const v = crypto.randomBytes(32).toString('hex'); setSetting(k, v); return v; }
  return null;
};
export const setSetting = (k, v) => db.prepare('INSERT INTO settings VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, String(v));
export const delSetting = k => db.prepare('DELETE FROM settings WHERE k=?').run(k);
