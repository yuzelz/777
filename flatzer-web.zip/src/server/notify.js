import { db } from './db.js';
import { tgSend } from './bot.js';
// Simpan notifikasi (toast di website) dan kirim ke Telegram user. text = {id, en}.
export function notify(userId, text, rows = []) {
  const u = db.prepare('SELECT tg_id,lang FROM users WHERE id=?').get(userId); if (!u) return;
  const msg = text[u.lang] || text.id;
  db.prepare('INSERT INTO notifs(user_id,msg) VALUES(?,?)').run(userId, msg);
  return tgSend(u.tg_id, msg, rows);
}
