import { cfg } from './config.js';
const BASE = 'https://app.pakasir.com/api/v2'; // API v1 dihentikan 20 Okt 2026
const hdr = { 'Content-Type': 'application/json', 'X-Api-Key': cfg.pakasir_api_key };
export async function createTxn(orderId, amount) {
  const r = await fetch(`${BASE}/create-transaction/${cfg.pakasir_slug}/${orderId}`, { method: 'POST', headers: hdr, body: JSON.stringify({ method: 'qris', amount }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.txn_id) throw new Error(j.message || j.error || 'PAKASIR_ERROR');
  return j; // {txn_id, fee, total_payment, qr_string, expired_at, ...}
}
export async function txnStatus(txnId) {
  const r = await fetch(`${BASE}/transaction-status/${cfg.pakasir_slug}/${txnId}`, { headers: hdr });
  return r.json().catch(() => ({})); // {status: pending|completed|canceled, order_id, amount}
}
