import fs from 'fs';
// Konfigurasi dibaca dari config.json (dibuat oleh install.sh, tidak ikut GitHub). Bukan env.
if (!fs.existsSync('config.json')) throw new Error('config.json tidak ditemukan. Jalankan ./install.sh atau salin config.example.json.');
export const cfg = JSON.parse(fs.readFileSync('config.json', 'utf8'));
