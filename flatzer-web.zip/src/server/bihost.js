import { cfg } from './config.js';
export async function bih(method, path, body) {
  const r = await fetch('https://api.bihost.id/v1' + path, { method, headers: { Authorization: `Bearer ${cfg.bihost_api_key}`, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.success === false) throw new Error(j.error?.code || j.code || 'BIHOST_ERROR');
  return j;
}
