import Database from 'better-sqlite3';
import fs from 'fs';
fs.mkdirSync('data', { recursive: true });
// Migrasi: taruh file backup di data/restore.db sebelum start, otomatis menggantikan database.
if (!globalThis.__db && fs.existsSync('data/restore.db')) { fs.copyFileSync('data/restore.db', 'data/flatzer.db'); fs.renameSync('data/restore.db', 'data/restore.db.done'); }
export const db = (globalThis.__db ||= new Database('data/flatzer.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,tg_id INTEGER UNIQUE,name TEXT,username TEXT,lang TEXT DEFAULT 'id',balance INTEGER DEFAULT 0,api_key TEXT UNIQUE,accepted INTEGER DEFAULT 0,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS logins(token TEXT PRIMARY KEY,tg_id INTEGER,name TEXT,username TEXT,created INTEGER,used INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id INTEGER,kind TEXT,amount INTEGER,status TEXT DEFAULT 'pending',txn_id TEXT,payload TEXT,checked INTEGER DEFAULT 0,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS vps(id TEXT PRIMARY KEY,user_id INTEGER,plan TEXT,data TEXT,expires_at INTEGER,auto INTEGER DEFAULT 0,warned TEXT DEFAULT '[]');
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE TABLE IF NOT EXISTS notifs(id INTEGER PRIMARY KEY,user_id INTEGER,msg TEXT,read INTEGER DEFAULT 0,at TEXT DEFAULT CURRENT_TIMESTAMP);`);
