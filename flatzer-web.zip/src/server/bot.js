import { Bot, InputFile } from 'grammy';
import { cfg } from './config.js';
import { db } from './db.js';
import { setSetting } from './settings.js';
import { dashUrl } from './base.js';

// Bot Telegram: hanya login dan notifikasi. Satu instance per proses.
export const bot = (globalThis.__bot ||= cfg.bot_token ? new Bot(cfg.bot_token) : null);
export { InputFile };

// Kirim Rich Message (tabel) ke Telegram; jika ditolak, kirim teks biasa.
export async function tgSend(tgId, title, rows = []) {
  if (!bot || !tgId) return;
  const blocks = [{ type: 'heading', text: title, size: 3 }];
  if (rows.length) blocks.push({ type: 'table', is_bordered: true, is_striped: true, cells: rows.map(r => r.map(c => ({ text: String(c), align: 'left', valign: 'middle' }))) });
  try { await bot.api.raw.sendRichMessage({ chat_id: tgId, rich_message: { blocks, skip_entity_detection: true } }); }
  catch { await bot.api.sendMessage(tgId, [title, ...rows.map(r => r.join(': '))].join('\n')).catch(() => {}); }
}
export function startBot() {
  if (!bot) { console.error('[flatzer] bot_token kosong di config.json: login Telegram tidak aktif'); return; }
  bot.command('start', async ctx => {
    const p = ctx.match || '';
    if (p.startsWith('login_')) {
      const l = db.prepare('SELECT * FROM logins WHERE token=?').get(p.slice(6));
      if (!l || l.used || l.tg_id || Date.now() - l.created > 10 * 60e3) return tgSend(ctx.from.id, 'Link login tidak valid atau kedaluwarsa / Login link is invalid or expired', [['', 'Buat ulang dari website / Retry from the website']]);
      db.prepare('UPDATE logins SET tg_id=?,name=?,username=? WHERE token=?').run(ctx.from.id, ctx.from.first_name || '', ctx.from.username || '', l.token);
      return tgSend(ctx.from.id, '✅ Login berhasil / Login successful', [['', 'Kembali ke website Flatzer / Return to the Flatzer website']]);
    }
    return tgSend(ctx.from.id, 'Flatzer NAT VPS', [['Website', dashUrl()], ['', 'Bot ini untuk login dan notifikasi / This bot is for login and notifications']]);
  });
  bot.catch(e => console.error('[bot]', e.error?.description || e.message));
  bot.start({ onStart: i => { setSetting('bot_username', i.username); console.log('[flatzer] bot @' + i.username); } });
}
