import { headers } from 'next/headers';
const SUB = /^((www|dash|api|docs)\.)+/;
const LOCAL = /^(localhost|\d+\.\d+\.\d+\.\d+)$/;
// URL tiap subdomain diturunkan dari host request, jadi domain mana pun langsung bekerja.
export function hostUrls() {
  const raw = headers().get('host') || 'localhost', host = raw.split(':')[0].toLowerCase(), base = host.replace(SUB, '');
  if (LOCAL.test(base) || !base.includes('.')) { const o = `http://${raw}`; return { local: true, base, main: o, dash: o, api: o + '/api', docs: o + '/docs' }; }
  return { local: false, base, main: `https://${base}`, dash: `https://dash.${base}`, api: `https://api.${base}/v1`, docs: `https://docs.${base}` };
}
