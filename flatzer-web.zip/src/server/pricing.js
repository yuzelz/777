import { cfg } from './config.js';
import { PLANS } from '../data/plans.js';
import { getSetting } from './settings.js';
export const markup = () => +(getSetting('markup') ?? cfg.markup_percent ?? 20);
export const norm = id => Math.ceil(PLANS[id][0] * (100 + markup()) / 10000) * 100;
export const promo = () => { const p = +(getSetting('promo_pct') || 0), u = +(getSetting('promo_until') || 0); return p && u > Date.now() ? { pct: p, until: u } : null; };
export const price = id => Math.ceil(norm(id) * (100 - (promo()?.pct || 0)) / 10000) * 100;
