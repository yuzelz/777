import { cookies } from 'next/headers';
import { DICT, makeT } from '@/i18n/index.js';
export const getLang = () => (cookies().get('lang')?.value === 'en' ? 'en' : 'id');
export const getT = () => { const lang = getLang(); return { lang, t: makeT(DICT[lang]) }; };
