'use client';
import { useState, useEffect, useRef } from 'react';
import Script from 'next/script';
import { useRouter } from 'next/navigation';
import { useT } from '@/components/I18n.js';
import { api } from '@/lib/format.js';

export default function LoginForm({ siteKey, home }) {
  const { t } = useT(), router = useRouter();
  const [ts, setTs] = useState(''), [link, setLink] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false), timer = useRef(null);
  useEffect(() => { window.__fzTs = setTs; return () => clearInterval(timer.current); }, []);
  async function start() {
    if (siteKey && !ts) return setMsg(t('login.verify'));
    setBusy(true); setMsg('');
    const r = await api('/api/auth/start', { turnstile: ts });
    if (r.error) { setBusy(false); return setMsg(t('err.' + r.error)); }
    setLink(r.url); window.open(r.url, '_blank');
    timer.current = setInterval(async () => {
      const p = await fetch('/api/auth/poll?token=' + r.token).then(x => x.json()).catch(() => ({}));
      if (p.ok) { clearInterval(timer.current); router.replace('/dashboard'); }
      else if (p.expired) { clearInterval(timer.current); setLink(''); setBusy(false); setMsg(t('login.expired')); }
    }, 2000);
  }
  return (
    <div className="card narrow center">
      <h2 style={{ fontSize: 28 }}>{t('login.title')}</h2>
      <p className="lead" style={{ margin: '8px auto 20px' }}>{t('login.sub')}</p>
      {siteKey && <><div className="cf-turnstile" data-sitekey={siteKey} data-callback="__fzTs" data-theme="dark" style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }} /><Script src="https://challenges.cloudflare.com/turnstile/v0/api.js" strategy="afterInteractive" /></>}
      <button className="btn primary" onClick={start} disabled={busy}>✈ {t('login.btn')}</button>
      {link && <p style={{ marginTop: 18 }}><span className="pill run">{t('login.wait')}</span><br /><a href={link} target="_blank" rel="noreferrer">{t('login.open')}</a></p>}
      {msg && <p className="err">{msg}</p>}
      <p style={{ marginTop: 20 }}><a href={home}>{t('login.back')}</a></p>
    </div>
  );
}
