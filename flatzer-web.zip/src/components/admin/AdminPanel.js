'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { api, rp } from '@/lib/format.js';

const Table = ({ head, rows }) => <div className="tw"><table><thead><tr>{head.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody></table></div>;
export default function AdminPanel() {
  const router = useRouter();
  const [d, setD] = useState(null), [m, setM] = useState(''), [f, setF] = useState({ markup: '', pct: '', hours: '', domain: '' });
  const ld = useCallback(async () => { const r = await api('/api/admin'); if (r.error) return router.replace('/login'); setD(r); }, [router]);
  useEffect(() => { ld(); }, [ld]);
  if (!d) return <main className="w"><p className="lead">…</p></main>;
  const op = async (body, ok) => { const r = await api('/api/admin', body); setM(r.error ? 'Error: ' + r.error : ok || 'OK'); ld(); };
  const base = d.base_domain;
  return (
    <main className="w">
      <header className="top"><a className="logo" href="/dashboard">Flat<b>zer</b> <small style={{ color: 'var(--mute)', fontSize: 14 }}>admin</small></a><a className="btn sm" href="/dashboard">Dashboard</a></header>
      {m && <p className="note" role="status">{m}</p>}
      <div className="grid g4">{[['Pengguna', d.stats.users], ['VPS aktif', d.stats.vps], ['Order lunas', d.stats.orders], ['Total saldo user', rp(d.stats.balance)]].map(([l, v]) => <div className="card stat" key={l}><b>{v}</b><span>{l}</span></div>)}</div>
      <section><h2>Harga &amp; promo</h2><div className="grid g3">
        <div className="card"><label>Markup (%) · sekarang {d.markup}%<input type="number" value={f.markup} onChange={e => setF({ ...f, markup: e.target.value })} /></label><button className="btn sm primary" onClick={() => op({ op: 'markup', value: f.markup }, 'Markup disimpan')}>Simpan</button></div>
        <div className="card"><label>Diskon nyata (%) {d.promo ? `· aktif ${d.promo.pct}%` : ''}<input type="number" value={f.pct} onChange={e => setF({ ...f, pct: e.target.value })} /></label><label>Durasi (jam)<input type="number" value={f.hours} onChange={e => setF({ ...f, hours: e.target.value })} /></label>
          <div className="row"><button className="btn sm primary" onClick={() => op({ op: 'promo', pct: +f.pct, hours: +f.hours }, 'Promo aktif')}>Aktifkan</button><button className="btn sm danger" onClick={() => op({ op: 'promo', pct: 0 }, 'Promo dimatikan')}>Matikan</button></div></div></div></section>
      <section><h2>Domain</h2><div className="card">
        <p className="lead">Domain utama sekarang: <code>{base}</code>. Untuk pindah domain: tambahkan hostname di Cloudflare Tunnel, simpan domain baru di sini, lalu perbarui dua pengaturan eksternal di bawah.</p>
        <label>Domain utama baru<input placeholder="contoh: flatzer.my.id" value={f.domain} onChange={e => setF({ ...f, domain: e.target.value })} /></label>
        <button className="btn sm primary" onClick={() => op({ op: 'domain', value: f.domain }, 'Domain disimpan')}>Simpan domain</button>
        <Table head={['Yang harus diarahkan ke Tunnel (http://localhost:3000)', 'Setelan eksternal']} rows={[[`${base}, www.${base}, dash.${base}, api.${base}, docs.${base}`, `Pakasir webhook: https://api.${base}/v1/webhook/pakasir · Turnstile hostname: ${base}`]]} /></div></section>
      <section><h2>Pengguna</h2><Table head={['ID', 'Telegram', 'Nama', 'Saldo', '']} rows={d.users.map(u => [u.id, u.tg_id, `${u.name || ''} ${u.username ? '@' + u.username : ''}`, rp(u.balance), <button className="btn sm" key="b" onClick={() => { const x = prompt('Tambah/kurangi saldo (angka, boleh negatif)'); if (x) op({ op: 'balance', user_id: u.id, delta: x }, 'Saldo diubah'); }}>Ubah saldo</button>])} /></section>
      <section><h2>VPS</h2><Table head={['ID', 'User', 'Paket', 'Kedaluwarsa', '']} rows={d.vps.map(v => [v.id, v.user_id, v.plan, new Date(v.expires_at).toLocaleString('id-ID'), <button className="btn sm danger" key="b" onClick={() => confirm('Hapus VPS ini?') && op({ op: 'delvps', id: v.id }, 'VPS dihapus')}>Hapus</button>])} /></section>
      <section><h2>Order terbaru</h2><Table head={['Order', 'User', 'Jenis', 'Nominal', 'Status', 'Waktu']} rows={d.orders.map(o => [o.id, o.user_id, o.kind, rp(o.amount), o.status, o.created])} />
        <p className="lead" style={{ marginTop: 14 }}>Backup otomatis harian ke Telegram admin. Terakhir: {d.last_backup ? new Date(d.last_backup).toLocaleString('id-ID') : 'belum ada'}.</p></section>
    </main>
  );
}
