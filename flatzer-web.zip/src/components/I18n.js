'use client';
import { createContext, useContext, useMemo } from 'react';
import { makeT } from '@/i18n/index.js';
const Ctx = createContext({ t: k => k, lang: 'id' });
export default function I18n({ lang, dict, children }) {
  const value = useMemo(() => ({ lang, t: makeT(dict) }), [lang, dict]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useT = () => useContext(Ctx);
