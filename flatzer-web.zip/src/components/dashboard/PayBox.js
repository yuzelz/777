'use client';
import { useState, useEffect } from 'react';
import { api, rp } from '@/lib/format.js';
export default function PayBox({ t, order, say, reload, onClose }) {
  const [s, setS] = useState('pending');
  useEffect(() => {
    const i = setInterval(async () => {
      const r = await api('/api/orders/' + order.order_id);
      if (r.status && r.status !== 'pending') { clearInterval(i); setS(r.status); if (r.status === 'paid') { say(t('pb.done')); reload(); setTimeout(onClose, 2500); } }
    }, 5000);
    return () => clearInterval(i);
  }, [order.order_id]);
  return (
    <div className="card center" style={{ maxWidth: 440, margin: '0 auto' }}>
      <h3>{t('pb.title')}</h3>
      <div className="qr"><img src={order.qr} alt="QRIS" /></div>
      <dl className="kv"><dt>{t('pb.total')}</dt><dd><b>{rp(order.total_payment)}</b></dd><dt>{t('pb.fee')}</dt><dd>{rp(order.fee || 0)}</dd><dt>{t('pb.expires')}</dt><dd>{order.expired_at}</dd></dl>
      <p><span className={s === 'paid' ? 'pill run' : 'pill'}>{s === 'paid' ? t('pb.done') : s === 'canceled' ? t('pb.canceled') : t('pb.waiting')}</span></p>
      <button className="btn sm" onClick={onClose}>×</button>
    </div>
  );
}
