'use client';
import { api } from '@/lib/format.js';
import { useState } from 'react';
export default function ApiKey({ t, me, say, reload }) {
  const [key, setKey] = useState(me.api_key);
  const base = typeof location === 'undefined' ? '' : location.host.startsWith('dash.') ? location.origin.replace('//dash.', '//api.') + '/v1' : location.origin + '/api';
  return (
    <div className="card" style={{ maxWidth: 760 }}>
      <p className="lead">{t('ap.desc')}</p>
      <label>{t('ap.key')}<input readOnly value={key} onFocus={e => e.target.select()} className="mono" /></label>
      <div className="row"><button className="btn sm" onClick={() => { navigator.clipboard?.writeText(key); say(t('d.copied')); }}>{t('d.copy')}</button>
        <button className="btn sm danger" onClick={async () => { const r = await api('/api/me', { rotate: true }); if (r.api_key) { setKey(r.api_key); reload(); } }}>Regenerate</button></div>
      <pre className="mono" style={{ overflowX: 'auto', background: '#0a0f16', padding: 14, borderRadius: 10, border: '1px solid var(--line)' }}>{`curl -H "Authorization: Bearer ${key}" ${base}/vps`}</pre>
    </div>
  );
}
