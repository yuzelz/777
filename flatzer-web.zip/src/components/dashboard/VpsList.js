'use client';
import { useState } from 'react';
import { api, rp, label, genpw } from '@/lib/format.js';

function Ports({ id, t, say, err }) {
  const [l, setL] = useState(null), [p, setP] = useState(''), [pr, setPr] = useState('tcp');
  const ld = async () => { const r = await api('/api/vps', { id, action: 'ports' }); r.error ? err(r.error) : setL(r.data || []); };
  return (
    <details onToggle={e => e.target.open && !l && ld()}><summary>{t('d.ports')}</summary>
      <ul>{(l || []).map(x => <li key={x.id}><code>{x.public_ip}:{x.public_port}</code> → {x.private_port}/{x.protocol} <button className="btn sm danger" onClick={async () => { await api('/api/vps', { id, action: 'delPort', port_id: x.id }); ld(); }}>×</button></li>)}</ul>
      <div className="row"><select style={{ width: 90 }} value={pr} onChange={e => setPr(e.target.value)}><option>tcp</option><option>udp</option></select>
        <input style={{ width: 200 }} aria-label={t('d.portIn')} placeholder={t('d.portIn')} value={p} onChange={e => setP(e.target.value)} />
        <button className="btn sm" onClick={async () => { const r = await api('/api/vps', { id, action: 'addPort', protocol: pr, private_port: +p }); r.error ? err(r.error) : (setP(''), ld()); }}>{t('d.addPort')}</button></div>
    </details>
  );
}
function Reinstall({ id, t, cat, say, err }) {
  const [img, setImg] = useState(cat.images[2][0]), [pw, setPw] = useState('');
  return (
    <details><summary>{t('d.reinstall')}</summary>
      <div className="row"><select style={{ width: 220 }} value={img} onChange={e => setImg(e.target.value)}>{cat.images.map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select>
        <input style={{ width: 220 }} aria-label={t('d.newPw')} placeholder={t('d.newPw')} value={pw} onChange={e => setPw(e.target.value)} />
        <button className="btn sm" onClick={() => setPw(genpw())}>{t('b.gen')}</button>
        <button className="btn sm danger" onClick={async () => { if (pw.length < 8) return err('INVALID_INPUT'); const r = await api('/api/vps', { id, action: 'reinstall', image_vmid: +img, root_password: pw }); r.error ? err(r.error) : say(t('d.reOk')); }}>{t('d.reinstall')}</button></div>
    </details>
  );
}
export default function VpsList(ctx) {
  const { t, lang, me, say, err, reload, onOrder } = ctx;
  const act = async (id, action, extra) => { const r = await api('/api/vps', { id, action, ...extra }); r.error ? err(r.error) : (say(t('d.sent')), reload()); };
  const renew = async (id, pay) => { const r = await api('/api/pay', { kind: 'renew', id, pay }); if (r.error) return err(r.error); r.order_id ? onOrder(r) : (say(t('d.renewed')), reload()); };
  if (!me.vps.length) return <p className="lead">{t('d.noVps')}</p>;
  return (
    <div className="grid">{me.vps.map(v => {
      const ssh = `ssh root@${v.access?.ipv4} -p ${v.access?.ssh_port}`;
      return (
        <div className="card" key={v.id}>
          <div className="row" style={{ justifyContent: 'space-between' }}><h3>{v.hostname}</h3><span className={v.status === 'running' ? 'pill run' : 'pill'}>{v.status} · {label(v.plan)}</span></div>
          <dl className="kv" style={{ margin: '12px 0' }}>
            <dt>{t('d.ssh')}</dt><dd><code>{ssh}</code> <button className="btn sm" onClick={() => { navigator.clipboard?.writeText(ssh); say(t('d.copied')); }}>{t('d.copy')}</button></dd>
            <dt>{t('d.until')}</dt><dd>{new Date(v.expires_at).toLocaleDateString(lang === 'en' ? 'en-GB' : 'id-ID')}</dd>
            <dt>{t('d.auto')}</dt><dd><button className="btn sm" onClick={() => act(v.id, 'auto')}>{v.auto ? t('d.on') : t('d.off')}</button></dd>
          </dl>
          <div className="row">{['start', 'stop', 'restart'].map(a => <button key={a} className="btn sm" onClick={() => act(v.id, a)}>{a}</button>)}
            <button className="btn sm primary" onClick={() => renew(v.id, 'balance')}>{t('d.renewBal')}</button><button className="btn sm" onClick={() => renew(v.id, 'qris')}>{t('d.renewQr')}</button>
            <button className="btn sm danger" onClick={() => confirm(t('d.confirmDel')) && act(v.id, 'delete')}>{t('d.del')}</button></div>
          <Ports id={v.id} {...ctx} /><Reinstall id={v.id} {...ctx} />
        </div>
      );
    })}</div>
  );
}
