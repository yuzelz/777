'use client';
import { useState } from 'react';
import { api, rp, label, genpw } from '@/lib/format.js';
export default function BuyForm({ t, cat, me, say, err, reload, onOrder }) {
  const [f, setF] = useState({ plan: cat.plans[0].id, img: 9002, host: '', pw: '', pay: 'balance', accept: me.accepted }), [busy, setBusy] = useState(false);
  const set = (k, v) => setF(x => ({ ...x, [k]: v }));
  async function submit() {
    setBusy(true);
    const r = await api('/api/pay', { kind: 'vps', plan: f.plan, image_vmid: f.img, hostname: f.host, root_password: f.pw, pay: f.pay, accept: f.accept });
    setBusy(false);
    if (r.error) return err(r.error);
    if (r.order_id) return onOrder(r);
    say(t('b.done')); reload();
  }
  return (
    <div style={{ maxWidth: 760 }}>
      <h3 style={{ marginBottom: 12 }}>{t('b.plan')}</h3>
      <div className="pick">{cat.plans.map(p => <button key={p.id} aria-pressed={f.plan === p.id} onClick={() => set('plan', p.id)}>
        <b>{label(p.id)}</b><small>{p.cpu} vCPU · {p.ram} GB · {p.disk} GB {p.st}</small>
        <span className="mono">{cat.promo && <s>{rp(p.norm)}</s>}{rp(p.price)}</span> <small>{t('b.price')}{cat.promo ? ` · ${t('b.off', { pct: cat.promo.pct })}` : ''}</small></button>)}</div>
      <label>{t('b.os')}<select value={f.img} onChange={e => set('img', +e.target.value)}>{cat.images.map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select></label>
      <label>{t('b.host')} <small>({t('b.hostHint')})</small><input value={f.host} onChange={e => set('host', e.target.value)} /></label>
      <label>{t('b.pw')} <small>({t('b.pwHint')})</small><span className="row" style={{ flexWrap: 'nowrap' }}><input value={f.pw} onChange={e => set('pw', e.target.value)} /><button className="btn sm" style={{ marginTop: 6 }} onClick={() => set('pw', genpw())}>{t('b.gen')}</button></span></label>
      <label>{t('b.payWith')}<select value={f.pay} onChange={e => set('pay', e.target.value)}><option value="balance">{t('b.balance')} ({rp(me.balance)})</option><option value="qris">{t('b.qris')}</option></select></label>
      <label style={{ color: 'var(--text)' }}><input type="checkbox" checked={f.accept} onChange={e => set('accept', e.target.checked)} />{t('b.accept')} <a href="/terms" target="_blank">{t('b.tosLink')}</a></label>
      <button className="btn primary" disabled={busy || !f.accept} onClick={submit}>{t('b.submit')}</button>
    </div>
  );
}
