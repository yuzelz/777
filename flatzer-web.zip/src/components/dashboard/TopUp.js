'use client';
import { useState } from 'react';
import { api } from '@/lib/format.js';
export default function TopUp({ t, err, onOrder }) {
  const [a, setA] = useState(25000);
  return (
    <div className="card" style={{ maxWidth: 440 }}>
      <h3 style={{ marginBottom: 14 }}>{t('tp.title')}</h3>
      <label>{t('tp.amount')}<input type="number" min="500" value={a} onChange={e => setA(e.target.value)} /></label>
      <button className="btn primary" onClick={async () => { const r = await api('/api/pay', { kind: 'topup', amount: a }); r.error ? err(r.error) : onOrder(r); }}>{t('tp.create')}</button>
      <p className="lead" style={{ marginTop: 14, fontSize: 14 }}>{t('tp.note')}</p>
    </div>
  );
}
