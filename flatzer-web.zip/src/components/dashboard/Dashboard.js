'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useT } from '@/components/I18n.js';
import LangSwitch from '@/components/LangSwitch.js';
import { api, rp } from '@/lib/format.js';
import VpsList from './VpsList.js';
import BuyForm from './BuyForm.js';
import TopUp from './TopUp.js';
import PayBox from './PayBox.js';
import ApiKey from './ApiKey.js';

export default function Dashboard() {
  const { t, lang } = useT(), router = useRouter();
  const [me, setMe] = useState(null), [cat, setCat] = useState(null), [tab, setTab] = useState('vps'), [toast, setToast] = useState(''), [order, setOrder] = useState(null);
  const say = useCallback(m => setToast(m), []);
  const err = useCallback(e => { const k = 'err.' + e; const m = t(k); say(m === k ? t('err.generic', { e }) : m); }, [t, say]);
  const load = useCallback(async () => {
    const m = await api('/api/me');
    if (m.error === 'UNAUTHORIZED') return router.replace('/login');
    setMe(m); if (m.notifs?.length) { say(m.notifs[m.notifs.length - 1].msg); api('/api/me', {}); }
  }, [router, say]);
  useEffect(() => { load(); api('/api/catalog').then(setCat); const i = setInterval(load, 10000); return () => clearInterval(i); }, [load]);
  useEffect(() => { if (toast) { const x = setTimeout(() => setToast(''), 6000); return () => clearTimeout(x); } }, [toast]);
  if (!me || !cat) return <main className="w"><p className="lead">…</p></main>;
  const ctx = { t, lang, me, cat, say, err, reload: load, onOrder: o => { setOrder(o); setTab('pay'); } };
  return (
    <>
      <header className="w top">
        <a className="logo" href="/dashboard">Flat<b>zer</b></a>
        <div className="right"><span className="pill">{me.name || ''}{me.username ? ` @${me.username}` : ''}</span><span className="pill run">{t('d.balance')} {rp(me.balance)}</span>
          {me.is_admin && <a href="/admin">{t('d.admin')}</a>}<LangSwitch lang={lang} />
          <button className="btn sm" onClick={async () => { await api('/api/auth/logout', {}); router.replace('/login'); }}>{t('d.logout')}</button></div>
      </header>
      <main className="w">
        <nav className="tabs">{['vps', 'buy', 'bal', 'api'].map(k => <button key={k} aria-current={tab === k ? 'true' : undefined} onClick={() => setTab(k)}>{t('d.tabs.' + k)}</button>)}</nav>
        {tab === 'pay' && order && <PayBox {...ctx} order={order} onClose={() => { setOrder(null); setTab('vps'); }} />}
        {tab === 'vps' && <VpsList {...ctx} />}
        {tab === 'buy' && <BuyForm {...ctx} />}
        {tab === 'bal' && <TopUp {...ctx} />}
        {tab === 'api' && <ApiKey {...ctx} />}
      </main>
      {toast && <div className="toast" role="status">{toast}</div>}
    </>
  );
}
