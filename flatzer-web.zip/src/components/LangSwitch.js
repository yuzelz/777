export default function LangSwitch({ lang }) {
  return <nav className="lang" aria-label="Language">{['id', 'en'].map(l => <a key={l} href={`/api/lang?l=${l}`} aria-current={lang === l ? 'true' : undefined}>{l.toUpperCase()}</a>)}</nav>;
}
