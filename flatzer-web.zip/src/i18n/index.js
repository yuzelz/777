import id from './id.js';
import en from './en.js';
export const DICT = { id, en };
export function makeT(dict) {
  return (key, vars) => {
    let v = key.split('.').reduce((o, k) => o?.[k], dict);
    if (typeof v === 'string' && vars) for (const [k, x] of Object.entries(vars)) v = v.replaceAll(`{${k}}`, x);
    return v ?? key;
  };
}
