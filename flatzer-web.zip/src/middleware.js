import { NextResponse } from 'next/server';
// Routing per subdomain. Tanpa domain hardcode: pakai label pertama host, jadi bisa pindah domain.
const hits = new Map();
const LOCAL = /^(localhost|\d+\.\d+\.\d+\.\d+|\[)/;
export function middleware(req) {
  const host = (req.headers.get('host') || '').toLowerCase().split(':')[0].replace(/^(www\.)+/, '');
  const p = req.nextUrl.pathname;
  if (LOCAL.test(host) || p.startsWith('/_next') || p === '/favicon.ico') return NextResponse.next();
  const url = req.nextUrl.clone(), rw = path => { url.pathname = path; return NextResponse.rewrite(url); }, sub = host.split('.')[0];
  if (sub === 'api') {
    const key = req.headers.get('authorization') || req.headers.get('cf-connecting-ip') || 'anon', now = Date.now(), h = (hits.get(key) || []).filter(t => now - t < 60000);
    h.push(now); hits.set(key, h); if (hits.size > 5000) hits.clear();
    if (h.length > 120) return NextResponse.json({ error: 'RATE_LIMITED' }, { status: 429 });
    if (p === '/' || p === '/v1' || p === '/v1/') return rw('/api');
    if (p.startsWith('/v1/')) return rw('/api/' + p.slice(4));
    return NextResponse.json({ error: 'NOT_FOUND', hint: 'Gunakan /v1/...' }, { status: 404 });
  }
  if (sub === 'docs') return p === '/' ? rw('/docs') : p === '/api/lang' ? NextResponse.next() : rw('/_nf');
  if (sub === 'dash') return p === '/' ? rw('/dashboard') : /^\/(login|dashboard|admin|api\/)/.test(p) ? NextResponse.next() : rw('/_nf');
  // domain utama: landing + syarat; login & dashboard dialihkan ke dash.
  if (p === '/login' || p === '/dashboard' || p === '/admin') { const d = new URL(req.url); d.host = 'dash.' + host; d.port = ''; return NextResponse.redirect(d); }
  return p === '/' || p === '/terms' || p === '/api/lang' ? NextResponse.next() : rw('/_nf');
}
