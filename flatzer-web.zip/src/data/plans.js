// [harga dasar BIHost, vCPU, RAM GB, disk GB, storage]
export const PLANS = {
  'kvm-starter': [31000, 1, 1, 32, 'HDD'], 'kvm-bronze': [62000, 2, 2, 64, 'HDD'], 'kvm-silver': [94000, 2, 4, 128, 'HDD'],
  'kvm-gold': [188000, 4, 8, 256, 'HDD'], 'kvm-platinum': [376000, 8, 16, 512, 'HDD'], 'kvm-titan': [628000, 12, 32, 768, 'HDD'],
  'kvm-ultimate': [1008000, 16, 64, 1024, 'HDD'], 'kvm-performance': [122000, 2, 4, 100, 'NVMe'],
};
export const IMAGES = [[9000, 'Ubuntu 24.04 KVM'], [9001, 'Ubuntu 22.04 KVM'], [9002, 'Debian 12 KVM'], [9003, 'AlmaLinux 9 KVM'], [9005, 'Ubuntu 24.04 + Docker KVM'], [9100, 'Ubuntu 24.04 LXC'], [9101, 'Ubuntu 22.04 LXC'], [9102, 'Debian 12 LXC'], [9103, 'AlmaLinux 9 LXC'], [9104, 'Alpine 3.22 LXC']];
export const planLabel = id => id.replace('kvm-', '').toUpperCase();
