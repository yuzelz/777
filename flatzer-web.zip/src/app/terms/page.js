import Link from 'next/link';
import { getT } from '@/server/lang.js';
import LangSwitch from '@/components/LangSwitch.js';
import { hostUrls } from '@/server/host.js';
export default function Terms() {
  const { t, lang } = getT(), u = hostUrls();
  return (
    <main className="w">
      <header className="top"><a className="logo" href={u.main}>Flat<b>zer</b></a><LangSwitch lang={lang} /></header>
      <section><h1 style={{ textAlign: 'left', margin: '0 0 24px', fontSize: 40 }}>{t('tos.title')}</h1>
        <ol style={{ maxWidth: '70ch', paddingLeft: 22 }}>{t('tos.items').map(x => <li key={x} style={{ marginBottom: 14 }}>{x}</li>)}</ol></section>
    </main>
  );
}
