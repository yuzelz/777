import { getT } from '@/server/lang.js';
import { hostUrls } from '@/server/host.js';
import LangSwitch from '@/components/LangSwitch.js';
export const metadata = { title: 'API Docs — Flatzer' };
const EP = [
  ['GET', '/me', 'Profil, saldo, daftar VPS / Profile, balance, VPS list'],
  ['POST', '/me', '{"rotate":true} → API key baru / new API key'],
  ['GET', '/catalog', 'Paket, harga, image OS, promo / Plans, prices, OS images, promo'],
  ['POST', '/pay', '{"kind":"topup","amount":25000} · {"kind":"vps","plan","image_vmid","hostname","root_password","pay":"balance|qris","accept":true} · {"kind":"renew","id","pay"}'],
  ['GET', '/orders/{order_id}', 'Status order QRIS: pending | paid | canceled'],
  ['GET', '/vps', 'Daftar VPS + saldo / VPS list + balance'],
  ['POST', '/vps', '{"id","action": start|stop|restart|reinstall|ports|addPort|delPort|auto|delete, …}'],
];
const Code = ({ children }) => <pre className="mono" style={{ overflowX: 'auto', background: '#0a0f16', padding: 14, borderRadius: 10, border: '1px solid var(--line)' }}>{children}</pre>;
export default function Docs() {
  const { lang } = getT(), u = hostUrls(), en = lang === 'en', api = u.api;
  return (
    <main className="w">
      <header className="top"><a className="logo" href={u.main}>Flat<b>zer</b> <small style={{ color: 'var(--mute)', fontSize: 14 }}>API</small></a><LangSwitch lang={lang} /></header>
      <section style={{ paddingTop: 24 }}>
        <h1 style={{ textAlign: 'left', margin: '0 0 12px', fontSize: 42 }}>{en ? 'Flatzer API v1' : 'API Flatzer v1'}</h1>
        <p className="lead">{en ? 'Every dashboard feature is available over REST/JSON. Get your API key from the dashboard (API tab).' : 'Semua fitur dashboard tersedia lewat REST/JSON. Ambil API key di dashboard (tab API).'}</p>
        <h2 style={{ fontSize: 24 }}>{en ? 'Authentication' : 'Autentikasi'}</h2>
        <Code>{`Base URL: ${api}\nAuthorization: Bearer fz_YOUR_API_KEY\nContent-Type: application/json`}</Code>
        <p className="lead">{en ? 'Rate limit: 120 requests per minute. Beyond that you get HTTP 429 RATE_LIMITED.' : 'Batas: 120 request per menit. Lebih dari itu akan mendapat HTTP 429 RATE_LIMITED.'}</p>
        <h2 style={{ fontSize: 24, margin: '28px 0 12px' }}>Endpoint</h2>
        <div className="tw"><table><thead><tr><th>Method</th><th>Path</th><th>{en ? 'Description' : 'Keterangan'}</th></tr></thead><tbody>{EP.map(([m, p, d]) => <tr key={m + p}><td><span className="pill run">{m}</span></td><td><code>{p}</code></td><td>{d}</td></tr>)}</tbody></table></div>
        <h2 style={{ fontSize: 24, margin: '28px 0 12px' }}>{en ? 'Example: create a VPS from balance' : 'Contoh: buat VPS dari saldo'}</h2>
        <Code>{`curl -X POST ${api}/pay \\\n  -H "Authorization: Bearer fz_YOUR_API_KEY" -H "Content-Type: application/json" \\\n  -d '{"kind":"vps","plan":"kvm-starter","image_vmid":9002,"hostname":"srv1","root_password":"StrongPass123!","pay":"balance","accept":true}'`}</Code>
        <h2 style={{ fontSize: 24, margin: '28px 0 12px' }}>{en ? 'Errors' : 'Error'}</h2>
        <p className="lead">{en ? 'Errors return {"error":"CODE"} with the matching HTTP status. Common codes:' : 'Error berbentuk {"error":"KODE"} dengan status HTTP yang sesuai. Kode umum:'} <code>UNAUTHORIZED</code> · <code>INSUFFICIENT_BALANCE</code> · <code>INVALID_INPUT</code> · <code>TOS_REQUIRED</code> · <code>VPS_NOT_FOUND</code> · <code>INSUFFICIENT_CAPACITY</code> · <code>RATE_LIMITED</code></p>
      </section>
    </main>
  );
}
