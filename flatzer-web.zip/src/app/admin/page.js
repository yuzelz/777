import AdminPanel from '@/components/admin/AdminPanel.js';
export const metadata = { title: 'Admin — Flatzer' };
export default function Page() { return <AdminPanel />; }
