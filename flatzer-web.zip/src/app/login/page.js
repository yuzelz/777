import { cfg } from '@/server/config.js';
import { getT } from '@/server/lang.js';
import { hostUrls } from '@/server/host.js';
import LangSwitch from '@/components/LangSwitch.js';
import LoginForm from '@/components/LoginForm.js';
export default function Login() {
  const { lang } = getT(), u = hostUrls();
  return (
    <main className="w">
      <header className="top"><a className="logo" href={u.main}>Flat<b>zer</b></a><LangSwitch lang={lang} /></header>
      <LoginForm siteKey={cfg.turnstile_site_key || ''} home={u.main} />
    </main>
  );
}
