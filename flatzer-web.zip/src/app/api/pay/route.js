import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { getUser } from '@/server/auth.js';
import { PLANS } from '@/data/plans.js';
import { price } from '@/server/pricing.js';
import { charge, refund, deploy, extend, qrisOrder } from '@/server/orders.js';
const bad = (e, s = 422) => R.json({ error: e }, { status: s });
export async function POST(req) {
  const u = getUser(req); if (!u) return bad('UNAUTHORIZED', 401);
  const b = await req.json().catch(() => ({}));
  try {
    if (b.kind === 'topup') { const a = parseInt(b.amount); if (!(a >= 500)) return bad('MIN_500'); return R.json(await qrisOrder(u.id, 'topup', a, {})); } // minimal QRIS Pakasir: Rp 500
    if (b.kind === 'renew') {
      const v = db.prepare('SELECT * FROM vps WHERE id=? AND user_id=?').get(b.id, u.id); if (!v) return bad('VPS_NOT_FOUND', 404);
      const a = price(v.plan);
      if (b.pay !== 'balance') return R.json(await qrisOrder(u.id, 'renew', a, { id: v.id }));
      if (!charge(u.id, a)) return bad('INSUFFICIENT_BALANCE', 402);
      extend(v.id); return R.json({ ok: true });
    }
    if (b.kind !== 'vps' || !PLANS[b.plan] || !/^[a-z0-9]([a-z0-9.-]{0,60}[a-z0-9])?$/i.test(b.hostname || '') || (b.root_password || '').length < 8) return bad('INVALID_INPUT');
    if (!u.accepted && !b.accept) return bad('TOS_REQUIRED');
    db.prepare('UPDATE users SET accepted=1 WHERE id=?').run(u.id);
    const a = price(b.plan), p = { plan: b.plan, img: +b.image_vmid, host: b.hostname, pw: b.root_password };
    if (b.pay === 'balance') {
      if (!charge(u.id, a)) return bad('INSUFFICIENT_BALANCE', 402);
      try { return R.json({ ok: true, vps: await deploy(u.id, p) }); } catch (e) { refund(u.id, a); throw e; }
    }
    return R.json(await qrisOrder(u.id, 'vps', a, p));
  } catch (e) { return bad(e.message, 502); }
}
