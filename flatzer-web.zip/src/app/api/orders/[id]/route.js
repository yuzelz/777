import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { getUser } from '@/server/auth.js';
import { syncOrder } from '@/server/orders.js';
export const dynamic = 'force-dynamic';
export async function GET(req, { params }) {
  const u = getUser(req), o = u && db.prepare('SELECT * FROM orders WHERE id=? AND user_id=?').get(params.id, u.id);
  if (!o) return R.json({ error: 'NOT_FOUND' }, { status: 404 });
  return R.json({ status: await syncOrder(o).catch(() => o.status) });
}
