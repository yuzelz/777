import { NextResponse as R } from 'next/server';
export async function POST() { const r = R.json({ ok: true }); r.cookies.set('fz', '', { path: '/', maxAge: 0 }); return r; }
