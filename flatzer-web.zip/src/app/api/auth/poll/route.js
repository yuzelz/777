import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { newApiKey, signSession, cookieOpts } from '@/server/auth.js';
// Langkah 2: website menunggu sampai user menekan Start di bot, lalu membuat sesi.
export async function GET(req) {
  const l = db.prepare('SELECT * FROM logins WHERE token=?').get(new URL(req.url).searchParams.get('token') || '');
  if (!l || l.used || Date.now() - l.created > 10 * 60e3) return R.json({ ok: false, expired: true });
  if (!l.tg_id) return R.json({ ok: false });
  db.prepare('UPDATE logins SET used=1 WHERE token=?').run(l.token);
  let u = db.prepare('SELECT * FROM users WHERE tg_id=?').get(l.tg_id);
  if (!u) { const id = db.prepare('INSERT INTO users(tg_id,name,username,api_key) VALUES(?,?,?,?)').run(l.tg_id, l.name, l.username, newApiKey()).lastInsertRowid; u = { id }; }
  else db.prepare('UPDATE users SET name=?,username=? WHERE id=?').run(l.name, l.username, u.id);
  const res = R.json({ ok: true });
  res.cookies.set('fz', signSession(u.id), cookieOpts(req.headers.get('host')));
  return res;
}
