import { NextResponse as R } from 'next/server';
import crypto from 'crypto';
import { cfg } from '@/server/config.js';
import { db } from '@/server/db.js';
import { getSetting } from '@/server/settings.js';
// Langkah 1 login: verifikasi Turnstile, buat token, kembalikan link deep-link ke bot.
export async function POST(req) {
  const { turnstile } = await req.json().catch(() => ({}));
  if (cfg.turnstile_secret) {
    const f = new URLSearchParams({ secret: cfg.turnstile_secret, response: turnstile || '', remoteip: req.headers.get('cf-connecting-ip') || '' });
    const v = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: f }).then(r => r.json()).catch(() => ({}));
    if (!v.success) return R.json({ error: 'TURNSTILE_FAILED' }, { status: 403 });
  }
  const bot = getSetting('bot_username');
  if (!bot) return R.json({ error: 'BOT_OFFLINE' }, { status: 503 });
  const token = crypto.randomBytes(18).toString('base64url');
  db.prepare('DELETE FROM logins WHERE created<?').run(Date.now() - 36e5);
  db.prepare('INSERT INTO logins(token,created) VALUES(?,?)').run(token, Date.now());
  return R.json({ token, url: `https://t.me/${bot}?start=login_${token}` });
}
