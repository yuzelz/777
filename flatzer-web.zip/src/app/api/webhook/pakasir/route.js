import { NextResponse as R } from 'next/server';
import crypto from 'crypto';
import { cfg } from '@/server/config.js';
import { db } from '@/server/db.js';
import { txnStatus } from '@/server/pakasir.js';
import { markPaid } from '@/server/orders.js';
const eq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
// Webhook Pakasir v2: cek header X-Secret, lalu verifikasi ulang lewat API status transaksi (disarankan Pakasir).
export async function POST(req) {
  if (!cfg.pakasir_webhook_secret || !eq(req.headers.get('x-secret') || '', cfg.pakasir_webhook_secret)) return R.json({ error: 'FORBIDDEN' }, { status: 403 });
  const b = await req.json().catch(() => ({})), o = db.prepare('SELECT * FROM orders WHERE id=?').get(b.order_id);
  if (o && b.status === 'completed' && b.amount === o.amount) {
    const s = await txnStatus(o.txn_id);
    if (s.status === 'completed' && s.order_id === o.id && s.amount === o.amount) await markPaid(o.id);
  }
  return R.json({ ok: true });
}
