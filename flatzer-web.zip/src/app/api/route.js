import { NextResponse as R } from 'next/server';
export async function GET() { return R.json({ name: 'Flatzer API', version: 'v1', docs: 'Lihat docs. subdomain / see docs. subdomain' }); }
