import { NextResponse as R } from 'next/server';
import { PLANS, IMAGES } from '@/data/plans.js';
import { norm, price, promo } from '@/server/pricing.js';
export const dynamic = 'force-dynamic';
export async function GET() {
  return R.json({ images: IMAGES, promo: promo(), plans: Object.entries(PLANS).map(([id, [, cpu, ram, disk, st]]) => ({ id, cpu, ram, disk, st, norm: norm(id), price: price(id) })) });
}
