import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { getUser, isAdmin, newApiKey } from '@/server/auth.js';
export const dynamic = 'force-dynamic';
export async function GET(req) {
  const u = getUser(req); if (!u) return R.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  return R.json({
    name: u.name, username: u.username, tg_id: u.tg_id, balance: u.balance, api_key: u.api_key, accepted: !!u.accepted, lang: u.lang, is_admin: isAdmin(u),
    vps: db.prepare('SELECT * FROM vps WHERE user_id=?').all(u.id).map(v => ({ ...JSON.parse(v.data), plan: v.plan, expires_at: v.expires_at, auto: !!v.auto })),
    notifs: db.prepare('SELECT id,msg FROM notifs WHERE user_id=? AND read=0').all(u.id),
  });
}
export async function POST(req) {
  const u = getUser(req); if (!u) return R.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  if (b.rotate) { const k = newApiKey(); db.prepare('UPDATE users SET api_key=? WHERE id=?').run(k, u.id); return R.json({ ok: true, api_key: k }); }
  db.prepare('UPDATE notifs SET read=1 WHERE user_id=?').run(u.id); return R.json({ ok: true });
}
