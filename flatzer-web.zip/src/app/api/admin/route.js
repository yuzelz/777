import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { getUser, isAdmin } from '@/server/auth.js';
import { getSetting, setSetting, delSetting } from '@/server/settings.js';
import { bih } from '@/server/bihost.js';
import { markup, promo } from '@/server/pricing.js';
import { notify } from '@/server/notify.js';
import { configuredBase } from '@/server/base.js';
export const dynamic = 'force-dynamic';
const deny = () => R.json({ error: 'FORBIDDEN' }, { status: 403 });
export async function GET(req) {
  const u = getUser(req); if (!isAdmin(u)) return deny();
  const n = t => db.prepare(`SELECT COUNT(*) c FROM ${t}`).get().c;
  return R.json({
    markup: markup(), promo: promo(), base_domain: configuredBase(), last_backup: +(getSetting('last_backup') || 0),
    stats: { users: n('users'), vps: n('vps'), orders: db.prepare("SELECT COUNT(*) c FROM orders WHERE status='paid'").get().c, balance: db.prepare('SELECT COALESCE(SUM(balance),0) s FROM users').get().s },
    users: db.prepare('SELECT id,tg_id,name,username,balance FROM users ORDER BY id DESC LIMIT 200').all(),
    orders: db.prepare('SELECT id,user_id,kind,amount,status,created FROM orders ORDER BY rowid DESC LIMIT 100').all(),
    vps: db.prepare('SELECT id,user_id,plan,expires_at FROM vps').all(),
  });
}
export async function POST(req) {
  const u = getUser(req); if (!isAdmin(u)) return deny();
  const b = await req.json().catch(() => ({}));
  try {
    if (b.op === 'markup') { const m = parseFloat(b.value); if (!(m >= 0 && m <= 500)) return R.json({ error: 'INVALID' }, { status: 422 }); setSetting('markup', m); }
    else if (b.op === 'promo') {
      if (b.pct === 0) { delSetting('promo_pct'); delSetting('promo_until'); }
      else if (b.pct > 0 && b.pct < 100 && b.hours > 0) { setSetting('promo_pct', b.pct); setSetting('promo_until', Date.now() + b.hours * 36e5); }
      else return R.json({ error: 'INVALID' }, { status: 422 });
    }
    else if (b.op === 'domain') { const d = String(b.value || '').toLowerCase().trim(); if (!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(d)) return R.json({ error: 'INVALID' }, { status: 422 }); setSetting('base_domain', d); }
    else if (b.op === 'balance') { db.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(parseInt(b.delta), b.user_id); notify(b.user_id, { id: `Saldo disesuaikan admin: ${b.delta}.`, en: `Balance adjusted by admin: ${b.delta}.` }); }
    else if (b.op === 'delvps') { await bih('DELETE', `/vps/${b.id}`); db.prepare('DELETE FROM vps WHERE id=?').run(b.id); }
    else return R.json({ error: 'INVALID_OP' }, { status: 422 });
    return R.json({ ok: true });
  } catch (e) { return R.json({ error: e.message }, { status: 502 }); }
}
