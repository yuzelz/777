import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { getUser } from '@/server/auth.js';
import { bih } from '@/server/bihost.js';
export const dynamic = 'force-dynamic';
const rows = u => db.prepare('SELECT * FROM vps WHERE user_id=?').all(u.id).map(v => ({ ...JSON.parse(v.data), plan: v.plan, expires_at: v.expires_at, auto: !!v.auto }));
export async function GET(req) { const u = getUser(req); return u ? R.json({ balance: u.balance, vps: rows(u) }) : R.json({ error: 'UNAUTHORIZED' }, { status: 401 }); }
export async function POST(req) {
  const u = getUser(req); if (!u) return R.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const b = await req.json().catch(() => ({})), id = b.id;
  const v = db.prepare('SELECT * FROM vps WHERE id=? AND user_id=?').get(id, u.id); if (!v) return R.json({ error: 'VPS_NOT_FOUND' }, { status: 404 });
  const power = (a, st) => async () => { const r = await bih('POST', `/vps/${id}/${a}`); db.prepare("UPDATE vps SET data=json_set(data,'$.status',?) WHERE id=?").run(st, id); return r; };
  const acts = {
    start: power('start', 'running'), stop: power('stop', 'stopped'), restart: power('restart', 'running'),
    reinstall: () => bih('POST', `/vps/${id}/reinstall`, { image_vmid: +b.image_vmid, root_password: b.root_password }),
    ports: () => bih('GET', `/vps/${id}/ports`), addPort: () => bih('POST', `/vps/${id}/ports`, { protocol: b.protocol, private_port: +b.private_port }), delPort: () => bih('DELETE', `/vps/${id}/ports/${b.port_id}`),
    auto: async () => { db.prepare('UPDATE vps SET auto=1-auto WHERE id=?').run(id); return { ok: true }; },
    delete: async () => { const r = await bih('DELETE', `/vps/${id}`); db.prepare('DELETE FROM vps WHERE id=?').run(id); return r; },
  };
  if (!acts[b.action]) return R.json({ error: 'INVALID_ACTION' }, { status: 422 });
  try { return R.json(await acts[b.action]()); } catch (e) { return R.json({ error: e.message }, { status: 502 }); }
}
