import { NextResponse as R } from 'next/server';
import { db } from '@/server/db.js';
import { getUser, cookieOpts } from '@/server/auth.js';
export async function GET(req) {
  const l = new URL(req.url).searchParams.get('l') === 'en' ? 'en' : 'id', u = getUser(req);
  if (u) db.prepare('UPDATE users SET lang=? WHERE id=?').run(l, u.id);
  const res = R.redirect(req.headers.get('referer') || new URL('/', req.url));
  res.cookies.set('lang', l, { ...cookieOpts(req.headers.get('host')), httpOnly: false, maxAge: 31536000 });
  return res;
}
