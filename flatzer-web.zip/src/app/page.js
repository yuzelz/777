import { getT } from '@/server/lang.js';
import { db } from '@/server/db.js';
import { PLANS } from '@/data/plans.js';
import { norm, price, promo } from '@/server/pricing.js';
import { getStatus } from '@/server/status.js';
import { hostUrls } from '@/server/host.js';
import { rp, label } from '@/lib/format.js';
import LangSwitch from '@/components/LangSwitch.js';
export const dynamic = 'force-dynamic';

export default async function Home() {
  const { t, lang } = getT(), u = hostUrls(), st = await getStatus(), pr = promo();
  const n = q => db.prepare(`SELECT COUNT(*) c FROM ${q}`).get().c, login = u.dash + (u.local ? '/login' : '/login');
  const stats = [[n('users'), t('stats.users')], [n('vps'), t('stats.vps')], [Object.keys(PLANS).length, t('stats.plans')], [t('stats.speedV'), t('stats.speed')]];
  return (
    <>
      <header className="w top">
        <a className="logo" href="/">Flat<b>zer</b></a>
        <div className="right"><a href="#plans">{t('nav.plans')}</a><a href="#faq">{t('nav.faq')}</a><LangSwitch lang={lang} /><a className="btn primary sm" href={login}>{t('nav.login')}</a></div>
      </header>
      <main className="w">
        <div className="hero">
          <span className="badge"><i className="dot" />{t('hero.badge')}</span>
          <h1>{t('hero.title')}</h1>
          <p className="sub">{t('hero.sub')}</p>
          <div className="cta"><a className="btn primary" href={login}>{t('hero.cta')}</a><a className="btn" href="#plans">{t('hero.cta2')}</a></div>
        </div>
        <section><div className="grid g4">{stats.map(([v, l]) => <div className="card stat" key={l}><b>{v}</b><span>{l}</span></div>)}</div></section>
        <section><h2>{t('how.title')}</h2>
          <div className="grid g3">{t('how.steps').map(([h, d], i) => <div className="card step" key={h}><i>0{i + 1}</i><h3>{h}</h3><p>{d}</p></div>)}</div></section>
        <section id="plans"><h2>{t('plans.title')}</h2><p className="lead">{t('plans.sub')}</p>
          {pr && <span className="promo">{t('plans.promo', { pct: pr.pct, date: new Date(pr.until).toLocaleString(lang === 'en' ? 'en-GB' : 'id-ID') })}</span>}
          <p className="note">{t('plans.nat')}</p>
          <div className="tw"><table><thead><tr>{t('plans.cols').map(c => <th key={c}>{c}</th>)}<th /></tr></thead><tbody>
            {Object.entries(PLANS).map(([id, [, c, r, d, s]]) => <tr key={id}><td><b>{label(id)}</b></td><td>{c} vCPU</td><td>{r} GB</td><td>{d} GB {s}</td>
              <td className="p">{pr && <s>{rp(norm(id))}</s>}{rp(price(id))}</td><td><a className="btn sm" href={login}>{t('plans.order')}</a></td></tr>)}
          </tbody></table></div></section>
        <section><h2>{t('status.title')}</h2>
          <div className="grid g3">{Object.entries(t('status.items')).map(([k, name]) => <div className="card status" key={k}><span><i className={st[k] ? 'dot' : 'dot off'} />{name}</span><b style={{ color: st[k] ? 'var(--neon)' : 'var(--danger)' }}>{st[k] ? t('status.ok') : t('status.down')}</b></div>)}</div></section>
        <section id="faq"><h2>{t('faq.title')}</h2>{t('faq.items').map(([q, a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}</section>
        <section><div className="final"><h2>{t('cta.title')}</h2><p className="lead" style={{ margin: '0 auto 24px' }}>{t('hero.sub')}</p><a className="btn primary" href={login}>{t('cta.btn')}</a></div></section>
      </main>
      <footer className="w"><span>© Flatzer. {t('foot.rights')}</span><span><a href="/terms">{t('nav.terms')}</a> · <a href={u.docs}>Docs</a></span></footer>
    </>
  );
}
