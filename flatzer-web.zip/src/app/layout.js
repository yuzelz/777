import './globals.css';
import I18n from '@/components/I18n.js';
import { getLang } from '@/server/lang.js';
import { DICT } from '@/i18n/index.js';
export const metadata = { title: 'Flatzer — VPS NAT Indonesia', description: 'VPS NAT berbasis KVM. Login dengan Telegram, bayar dengan QRIS, aktif dalam hitungan detik.' };
export default function Root({ children }) {
  const lang = getLang();
  return (
    <html lang={lang}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" />
      </head>
      <body><I18n lang={lang} dict={DICT[lang]}>{children}</I18n></body>
    </html>
  );
}
