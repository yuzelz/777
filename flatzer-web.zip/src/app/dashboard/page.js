import Dashboard from '@/components/dashboard/Dashboard.js';
export const metadata = { title: 'Dashboard — Flatzer' };
export default function Page() { return <Dashboard />; }
