#!/usr/bin/env bash
# Instalasi Flatzer di VPS (Debian/Ubuntu): ./install.sh  (jalankan sebagai root)
set -euo pipefail
cd "$(dirname "$0")"
DIR="$(pwd)"
say() { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
ask() { local v; read -r -p "$1${2:+ [$2]}: " v; echo "${v:-${2:-}}"; }
asks() { local v; read -r -s -p "$1: " v; echo >&2; echo "$v"; }
[ "$(id -u)" -eq 0 ] || { echo "Jalankan sebagai root: sudo ./install.sh"; exit 1; }

say "1/5 Paket sistem dan Node.js"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg build-essential python3 git openssl
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi

say "2/5 Konfigurasi (disimpan di config.json, bukan env)"
if [ -f config.json ]; then
  echo "config.json sudah ada, dilewati."
else
  BASE=$(ask "Domain utama" "flatzer.my.id")
  ADMIN=$(ask "ID Telegram admin" "5979067091")
  BOT=$(asks "Token bot Telegram (dari @BotFather)")
  BIH=$(asks "API key BIHost")
  SLUG=$(ask "Pakasir: slug proyek")
  PK=$(asks "Pakasir: API key")
  WH=$(ask "Pakasir: secret webhook (kosong = dibuat acak)" "$(openssl rand -hex 16)")
  TSK=$(ask "Turnstile: site key")
  TSS=$(asks "Turnstile: secret key")
  MK=$(ask "Markup harga (%)" "20")
  node scripts/make-config.js "$BASE" "$ADMIN" "$BOT" "$BIH" "$SLUG" "$PK" "$WH" "$TSK" "$TSS" "$MK"
  echo "Secret webhook Pakasir (isi di dashboard Pakasir): $WH"
fi

say "3/5 Install dependensi dan build"
npm install --no-audit --no-fund
npm run build

say "4/5 Service systemd (flatzer)"
id flatzer >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin flatzer
mkdir -p data && chown -R flatzer:flatzer "$DIR" && chmod 600 config.json
cat > /etc/systemd/system/flatzer.service <<UNIT
[Unit]
Description=Flatzer (website, API, bot login+notifikasi)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=flatzer
WorkingDirectory=$DIR
Environment=NODE_ENV=production
ExecStart=$(command -v npm) start
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload && systemctl enable --now flatzer

say "5/5 Cloudflare Tunnel"
TOKEN=$(asks "Token Cloudflare Tunnel (kosong = lewati)")
if [ -n "$TOKEN" ]; then
  if ! command -v cloudflared >/dev/null; then
    mkdir -p --mode=0755 /usr/share/keyrings
    curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg > /usr/share/keyrings/cloudflare-main.gpg
    echo 'deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main' > /etc/apt/sources.list.d/cloudflared.list
    apt-get update -y && apt-get install -y cloudflared
  fi
  cloudflared service install "$TOKEN"
fi

BASE=$(node -p "require('./config.json').base_domain")
cat <<MSG

Selesai. Di Cloudflare Zero Trust > Networks > Tunnels > Public Hostname, arahkan SEMUA hostname ini ke HTTP localhost:3000:
  $BASE   www.$BASE   dash.$BASE   api.$BASE   docs.$BASE
Lalu set di layanan eksternal:
  Pakasir webhook URL : https://api.$BASE/v1/webhook/pakasir  (header X-Secret = secret di atas)
  Turnstile hostname  : $BASE
Cek log: journalctl -u flatzer -f
MSG
